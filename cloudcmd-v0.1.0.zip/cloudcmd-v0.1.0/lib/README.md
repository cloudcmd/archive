Cloud Commander Libraries
===============
**Cloud Commander Libraries** - dir thet contains scripts, thet uses 
on client and server side, and modules, wich is not necessary
for CloudCommander work, but they adds some sugor.