(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(this, function() {
return webpackJsonp([11],{

/***/ 36:
/* unknown exports provided */
/* all exports used */
/*!********************************!*\
  !*** ./client/modules/edit.js ***!
  \********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/* global CloudCmd */\n\n\n\nconst exec = __webpack_require__(/*! execon */ 0);\nconst currify = __webpack_require__(/*! currify/legacy */ 6);\n\nconst load = __webpack_require__(/*! ../dom/load */ 2);\n\nconst {MAX_FILE_SIZE: maxSize} = __webpack_require__(/*! ../../common/cloudfunc */ 4);\nconst {time, timeEnd} = __webpack_require__(/*! ../../common/util */ 5);\n\nCloudCmd.Edit = EditProto;\n\nfunction EditProto(callback) {\n    const Name = 'Edit';\n    const EditorName = CloudCmd.config('editor');\n    const loadFiles = currify(_loadFiles);\n    \n    let Loading = true;\n    let Element;\n    let editor;\n    \n    const ConfigView = {\n        afterShow: () => {\n            editor\n                .moveCursorTo(0, 0)\n                .focus();\n        }\n    };\n    \n    const Edit = exec.bind();\n    \n    function init(callback) {\n        const element = createElement();\n        \n        exec.series([\n            CloudCmd.View,\n            loadFiles(element)\n        ], callback);\n    }\n    \n    function createElement() {\n        const element = load({\n            name: 'div',\n            style:\n                'width      : 100%;'                +\n                'height     : 100%;'                +\n                'font-family: \"Droid Sans Mono\";'   +\n                'position   : absolute;',\n            notAppend: true\n        });\n        \n        Element = element;\n        \n        return element;\n    }\n    \n    function checkFn(name, fn) {\n        if (typeof fn !== 'function')\n            throw Error(name + ' should be a function!');\n    }\n    \n    function initConfig(options = {}) {\n        const config = Object.assign({}, options, ConfigView);\n        \n        if (options.afterShow) {\n            checkFn('options.afterShow', options.afterShow);\n            \n            const afterShow = {config};\n            \n            config.afterShow = () => {\n                afterShow();\n                options.afterShow();\n            };\n        }\n        \n        return config;\n    }\n    \n    Edit.show = (options) => {\n        if (Loading)\n            return;\n         \n        CloudCmd.View.show(Element, initConfig(options));\n    };\n    \n    Edit.getEditor = () => {\n        return editor;\n    };\n    \n    Edit.getElement = () => {\n        return Element;\n    };\n    \n    Edit.hide = () => {\n        CloudCmd.View.hide();\n    };\n    \n    function _loadFiles(element, callback) {\n        const socketPath = CloudCmd.PREFIX;\n        const prefix = socketPath + '/' + EditorName;\n        const url = prefix + '/' + EditorName + '.js';\n        \n        time(Name + ' load');\n        \n        load.js(url, () => {\n            const word = window[EditorName];\n            const options = {\n                maxSize,\n                prefix,\n                socketPath,\n            };\n            \n            word(element, options, (ed) => {\n                timeEnd(Name + ' load');\n                editor  = ed;\n                Loading = false;\n                \n                exec(callback);\n            });\n        });\n    }\n    \n    init(callback);\n    \n    return Edit;\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/edit.js\n// module id = 36\n// module chunks = 11\n\n//# sourceURL=file://cloudcmd/client/modules/edit.js");

/***/ })

},[36]);
});