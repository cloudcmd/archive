(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(this, function() {
return webpackJsonp([3],{

/***/ 44:
/* unknown exports provided */
/* all exports used */
/*!**********************************!*\
  !*** ./client/modules/upload.js ***!
  \**********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/* global CloudCmd, DOM */\n\n\n\nconst exec = __webpack_require__(/*! execon */ 0);\n\nconst load = __webpack_require__(/*! ../dom/load */ 2);\nconst Files = __webpack_require__(/*! ../dom/files */ 8);\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\nconst uploadFiles = __webpack_require__(/*! ../dom/upload-files */ 14);\n\nCloudCmd.Upload = UploadProto;\n\nfunction UploadProto() {\n    Images.show.load('top');\n    \n    exec.series([\n        CloudCmd.View,\n        show\n    ]);\n    \n    return exports;\n}\n\nmodule.exports.show = show;\nmodule.exports.hide = hide;\n\nfunction show() {\n    Images.show.load('top');\n    \n    Files.get('upload', (error, data) => {\n        const autoSize = true;\n        \n        CloudCmd.View.show(data, {\n            autoSize,\n            afterShow,\n        });\n    });\n    \n    const fontFamily = [\n        '\"Droid Sans Mono\"',\n        '\"Ubuntu Mono\"',\n        '\"Consolas\"',\n        'monospace'\n    ].join(', ');\n    \n    load.style({\n        id      : 'upload-css',\n        inner   : '[data-name=js-upload-file-button] {' +\n                      `font-family: ${fontFamily};`     +\n                      'font-size: 20px;'                +\n                      'width: 97%'                      +\n                '}'\n    });\n}\n\nfunction hide() {\n    CloudCmd.View.hide();\n}\n\nfunction afterShow() {\n    const button = DOM.getByDataName('js-upload-file-button');\n    \n    Images.hide();\n    \n    DOM.Events.add('change', button, ({target}) => {\n        const {files} = target;\n        \n        hide();\n        \n        uploadFiles(files);\n    });\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/upload.js\n// module id = 44\n// module chunks = 3\n\n//# sourceURL=file://cloudcmd/client/modules/upload.js");

/***/ })

},[44]);
});