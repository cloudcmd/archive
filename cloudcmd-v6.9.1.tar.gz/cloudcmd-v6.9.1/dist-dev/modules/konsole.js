(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(this, function() {
return webpackJsonp([9],{

/***/ 38:
/* unknown exports provided */
/* all exports used */
/*!***********************************!*\
  !*** ./client/modules/konsole.js ***!
  \***********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\n/* global CloudCmd */\n/* global Util */\n/* global DOM */\n/* global Console */\n\nconst exec = __webpack_require__(/*! execon */ 0);\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\nconst {Dialog} = __webpack_require__(/*! ../dom */ 7);\n\nCloudCmd.Konsole = ConsoleProto;\n\nfunction ConsoleProto() {\n    const config = CloudCmd.config;\n    \n    const Name = 'Konsole';\n    const TITLE = 'Console';\n    \n    let Element;\n    let Loaded;\n    \n    const Konsole = this;\n    \n    function init() {\n        Images.show.load('top');\n        \n        exec.series([\n            CloudCmd.View,\n            load,\n            create,\n            Konsole.show,\n        ]);\n        \n        Element = DOM.load({\n            name        : 'div',\n            className   : 'console'\n        });\n    }\n    \n    this.hide = () => {\n        CloudCmd.View.hide();\n    };\n    \n    this.clear = () => {\n        Console.clear();\n    };\n    \n    function getPrefix() {\n        return CloudCmd.PREFIX + '/console';\n    }\n    \n    function getEnv() {\n        return {\n            ACTIVE_DIR: DOM.getCurrentDirPath.bind(DOM),\n            PASSIVE_DIR: DOM.getNotCurrentDirPath.bind(DOM),\n            CURRENT_NAME: DOM.getCurrentName.bind(DOM),\n            CURRENT_PATH: () => {\n                return DOM.CurrentInfo.path;\n            }\n        };\n    }\n    \n    function create(callback) {\n        const options = {\n            env: getEnv(),\n            prefix: getPrefix(),\n            socketPath: CloudCmd.PREFIX,\n        };\n        \n        Console(Element, options, (spawn) => {\n            spawn.on('connect', exec.with(authCheck, spawn));\n            exec(callback);\n        });\n        \n        Console.addShortCuts({\n            'P': () => {\n                const command = Console.getPromptText();\n                const path = DOM.getCurrentDirPath();\n                \n                Console.setPromptText(command + path);\n            }\n        });\n    }\n    \n    function authCheck(spawn) {\n        if (!config('auth'))\n            return;\n        \n        spawn.emit('auth', config('username'), config('password'));\n        \n        spawn.on('reject', () => {\n            Dialog.alert(TITLE, 'Wrong credentials!');\n        });\n    }\n    \n    this.show = (callback) => {\n        if (!Loaded)\n            return;\n        \n        CloudCmd.View.show(Element, {\n            afterShow: () => {\n                Console.focus();\n                exec(callback);\n            }\n        });\n    };\n    \n    function load(callback) {\n        const prefix = getPrefix();\n        const url = prefix + '/console.js';\n        \n        DOM.load.js(url, (error) => {\n            if (error)\n                return Dialog.alert(TITLE, error.message);\n            \n            Loaded = true;\n            Util.timeEnd(Name + ' load');\n            exec(callback);\n        });\n        \n        Util.time(Name + ' load');\n    }\n    \n    if (!CloudCmd.config('console'))\n        return;\n    \n    init();\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/konsole.js\n// module id = 38\n// module chunks = 9\n\n//# sourceURL=file://cloudcmd/client/modules/konsole.js");

/***/ })

},[38]);
});