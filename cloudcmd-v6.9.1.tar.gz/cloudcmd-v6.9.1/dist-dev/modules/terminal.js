(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(this, function() {
return webpackJsonp([4],{

/***/ 43:
/* unknown exports provided */
/* all exports used */
/*!************************************!*\
  !*** ./client/modules/terminal.js ***!
  \************************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\n/* global CloudCmd, gritty */\n\nconst exec = __webpack_require__(/*! execon */ 0);\nconst load = __webpack_require__(/*! ../dom/load */ 2);\nconst DOM = __webpack_require__(/*! ../dom */ 7);\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\nconst {Dialog} = DOM;\n\nconst TITLE = 'Terminal';\n\nCloudCmd.Terminal = TerminalProto;\n\nconst {Key} = CloudCmd;\n\nlet Element;\nlet Loaded;\nlet Terminal;\n\nconst {config} = CloudCmd;\n\nfunction TerminalProto() {\n    if (!config('terminal'))\n        return;\n    \n    Images.show.load('top');\n    \n    exec.series([\n        CloudCmd.View,\n        loadAll,\n        create,\n        show,\n    ]);\n    \n    Element = load({\n        name: 'div',\n        style: 'height: 99%',\n        className : 'terminal',\n    });\n    \n    return module.exports;\n}\n\nmodule.exports.show = show;\n\nmodule.exports.hide = hide;\n\nfunction hide () {\n    CloudCmd.View.hide();\n}\n\nfunction getPrefix() {\n    return CloudCmd.PREFIX + '/gritty';\n}\n\nfunction getEnv() {\n    return {\n        ACTIVE_DIR: DOM.getCurrentDirPath,\n        PASSIVE_DIR: DOM.getNotCurrentDirPath,\n        CURRENT_NAME: DOM.getCurrentName,\n        CURRENT_PATH: DOM.getCurrentPath\n    };\n}\n\nfunction create(callback) {\n    const options = {\n        env: getEnv(),\n        prefix: getPrefix(),\n        socketPath: CloudCmd.PREFIX,\n    };\n    \n    const {socket, terminal} = gritty(Element, options);\n    \n    terminal.focus();\n    \n    Terminal = terminal;\n    \n    terminal.on('key', (char, {keyCode, shiftKey}) => {\n        if (shiftKey && keyCode === Key.ESC) {\n            hide();\n        }\n    });\n    \n    socket.on('connect', exec.with(authCheck, socket));\n    \n    exec(callback);\n}\n\nfunction authCheck(spawn) {\n    if (!config('auth'))\n        return;\n    \n    spawn.emit('auth', config('username'), config('password'));\n    \n    spawn.on('reject', () => {\n        Dialog.alert(TITLE, 'Wrong credentials!');\n    });\n}\n\nfunction show(callback) {\n    if (!Loaded)\n        return;\n    \n    CloudCmd.View.show(Element, {\n        afterShow: () => {\n            if (Terminal) {\n                Terminal.fit(); // lines corrupt without\n                Terminal.focus();\n            }\n            \n            exec(callback);\n        }\n    });\n}\n\nfunction loadAll(callback) {\n    const prefix = getPrefix();\n    const url = prefix + '/gritty.js';\n    \n    DOM.load.js(url, (error) => {\n        if (error)\n            return Dialog.alert(TITLE, error.message);\n        \n        Loaded = true;\n        exec(callback);\n    });\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/terminal.js\n// module id = 43\n// module chunks = 4\n\n//# sourceURL=file://cloudcmd/client/modules/terminal.js");

/***/ })

},[43]);
});