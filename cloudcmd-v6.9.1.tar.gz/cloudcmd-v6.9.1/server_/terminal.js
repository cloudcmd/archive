'use strict';

var tryCatch = require('try-catch');
var config = require('./config');

var noop = function noop() {};
noop.listen = noop;

module.exports = getTerminal(config('terminal'));

function getTerminal(term) {
    if (!term) return noop;

    var result = void 0;

    var e = tryCatch(function () {
        result = require(config('terminalPath'));
    });

    if (!e) return result;

    config('terminal', false);
    console.log('cloudcmd --terminal: ' + e.message);

    return noop;
}