'use strict';

var DIR = __dirname + '/';
var DIR_ROOT = DIR + '../';
var DIR_COMMON = DIR + '../common/';

var cloudfunc = require(DIR_COMMON + 'cloudfunc');

var auth = require(DIR + 'auth');
var config = require(DIR + 'config');
var rest = require(DIR + 'rest');
var route = require(DIR + 'route');
var validate = require(DIR + 'validate');
var prefixer = require(DIR + 'prefixer');
var pluginer = require(DIR + 'plugins');

var apart = require('apart');
var join = require('join-io');
var ponse = require('ponse');
var mollify = require('mollify');
var restafary = require('restafary');
var konsole = require('console-io/legacy');
var edward = require('edward/legacy');
var dword = require('dword/legacy');
var deepword = require('deepword/legacy');
var nomine = require('nomine/legacy');
var spero = require('spero');
var remedy = require('remedy');
var ishtar = require('ishtar');
var salam = require('salam/legacy');
var criton = require('criton');

var root = function root() {
    return config('root');
};
var emptyFunc = function emptyFunc(req, res, next) {
    return next();
};
emptyFunc.middle = function () {
    return emptyFunc;
};

function getPrefix(prefix) {
    if (typeof prefix === 'function') return prefix() || '';

    return prefix || '';
}

module.exports = function (params) {
    var p = params || {};
    var options = p.config || {};
    var plugins = p.plugins;
    var keys = Object.keys(options);

    var prefix = void 0;

    checkPlugins(plugins);

    keys.forEach(function (name) {
        var value = options[name];

        switch (name) {
            case 'root':
                validate.root(value);
                break;
            case 'editor':
                validate.editor(value);
                break;
            case 'packer':
                validate.packer(value);
                break;
            case 'password':
                /* could be useful when used as middleware */
                value = criton(value, config('algo'));
                break;
            case 'prefix':
                prefix = prefixer(value);
                break;
        }

        config(name, value);
    });

    var console = config('console');
    var configDialog = config('configDialog');

    config('console', defaultValue(options.console, console));
    config('configDialog', defaultValue(options.configDialog, configDialog));

    if (p.socket) listen(prefix, p.socket);

    return cloudcmd(prefix, plugins);
};

function defaultValue(value, previous) {
    if (typeof value === 'undefined') return previous;

    return value;
}

function authCheck(socket, success) {
    if (!config('auth')) return success();

    socket.on('auth', function (name, pass) {
        var isName = name === config('username');
        var isPass = pass === config('password');

        if (isName && isPass) {
            success();
            socket.emit('accept');
        } else {
            socket.emit('reject');
        }
    });
}

function listen(prefix, socket) {
    var size = cloudfunc.MAX_SIZE;

    prefix = getPrefix(prefix);

    config.listen(socket, authCheck);

    edward.listen(socket, {
        size: size,
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/edward'
    });

    dword.listen(socket, {
        size: size,
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/dword'
    });

    deepword.listen(socket, {
        size: size,
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/deepword'
    });

    spero.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/spero'
    });

    remedy.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/remedy'
    });

    ishtar.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/ishtar'
    });

    salam.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/salam'
    });

    config('console') && konsole.listen(socket, {
        authCheck: authCheck,
        prefix: prefix + '/console'
    });
}

function cloudcmd(prefix, plugins) {
    var isOption = function isOption(name) {
        return config(name);
    };

    var isMinify = apart(isOption, 'minify');
    var isOnline = apart(isOption, 'online');
    var isCache = apart(isOption, 'cache');
    var isDiff = apart(isOption, 'diff');
    var isZip = apart(isOption, 'zip');

    var ponseStatic = ponse.static(DIR_ROOT, {
        cache: isCache
    });

    var funcs = [konsole({
        prefix: prefix + '/console',
        minify: isMinify,
        online: isOnline
    }), edward({
        prefix: prefix + '/edward',
        minify: isMinify,
        online: isOnline,
        diff: isDiff,
        zip: isZip
    }), dword({
        prefix: prefix + '/dword',
        minify: isMinify,
        online: isOnline,
        diff: isDiff,
        zip: isZip
    }), deepword({
        prefix: prefix + '/deepword',
        minify: isMinify,
        online: isOnline,
        diff: isDiff,
        zip: isZip
    }), spero({
        prefix: prefix + '/spero',
        minify: isMinify,
        online: isOnline
    }), remedy({
        prefix: prefix + '/remedy',
        minify: isMinify,
        online: isOnline
    }), ishtar({
        prefix: prefix + '/ishtar',
        minify: isMinify,
        online: isOnline
    }), salam({
        prefix: prefix + '/salam'
    }), nomine({
        prefix: prefix + '/rename'
    }), setUrl(prefix), logout, auth(), config.middle, restafary({
        prefix: cloudfunc.apiURL + '/fs',
        root: root
    }), rest, route, join({
        dir: DIR_ROOT,
        minify: isMinify
    }), mollify({
        dir: DIR_ROOT,
        is: isMinify
    }), pluginer(plugins), ponseStatic];

    return funcs;
}

function logout(req, res, next) {
    if (req.url !== '/logout') return next();

    res.sendStatus(401);
}

function setUrl(pref) {
    return function (req, res, next) {
        var prefix = getPrefix(pref);
        var is = !req.url.indexOf(prefix);

        if (!is) return next();

        req.url = req.url.replace(prefix, '') || '/';

        if (req.url === '/cloudcmd.js') req.url = '/client/cloudcmd.js';

        next();
    };
}

function checkPlugins(plugins) {
    if (typeof plugins === 'undefined') return;

    if (!Array.isArray(plugins)) throw Error('plugins should be an array!');
}