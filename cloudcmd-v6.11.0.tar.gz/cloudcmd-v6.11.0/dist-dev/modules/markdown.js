webpackJsonp([8],{

/***/ 40:
/* unknown exports provided */
/* all exports used */
/*!************************************!*\
  !*** ./client/modules/markdown.js ***!
  \************************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\n/*global CloudCmd */\n\nCloudCmd.Markdown = MarkdownProto;\n\nconst exec = __webpack_require__(/*! execon */ 0);\n\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\nconst load = __webpack_require__(/*! ../dom/load */ 2);\nconst {Markdown} = __webpack_require__(/*! ../dom/rest */ 10);\n\nfunction MarkdownProto(name, options) {\n    Images.show.load('top');\n    \n    exec.series([\n        CloudCmd.View,\n        exec.with(show, name, options),\n    ]);\n    \n    return module.exports;\n}\n\nmodule.exports.show = show;\n\nmodule.exports.hide = () => {\n    CloudCmd.View.hide();\n};\n\n\nfunction show(name, options = {}) {\n    const relativeQuery = '?relative';\n    const {\n        positionLoad,\n        relative,\n    } = options;\n    \n    Images.show.load(positionLoad);\n    \n    if (relative)\n        name += relativeQuery;\n    \n    Markdown.read(name, (error, inner) => {\n        const name = 'div';\n        const className = 'help';\n        \n        const div = load({\n            name,\n            className,\n            inner,\n        });\n        \n        Images.hide();\n        \n        CloudCmd.View.show(div);\n    });\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/markdown.js\n// module id = 40\n// module chunks = 8\n\n//# sourceURL=file://cloudcmd/client/modules/markdown.js");

/***/ })

},[40]);