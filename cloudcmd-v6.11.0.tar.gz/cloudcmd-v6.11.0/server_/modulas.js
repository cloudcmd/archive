'use strict';

var deepmerge = require('deepmerge');
var originalModules = require('../json/modules');

module.exports = function () {
    var modules = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var result = deepmerge(originalModules, modules);

    return function (req, res, next) {
        if (req.url !== '/json/modules.json') return next();

        res.send(result);
    };
};