'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var t = require('table');
var table = t.table;
var getBorderCharacters = t.getBorderCharacters;

module.exports = function (config) {
    check(config);

    var data = Object.keys(config).map(function (name) {
        return [name, config[name]];
    });

    if (!data.length) return '';

    return table(data, {
        columns: {
            1: {
                width: 30,
                truncate: 30
            }
        },
        border: getBorderCharacters('ramac')
    });
};

function check(config) {
    if (!config) throw Error('config could not be empty!');

    if ((typeof config === 'undefined' ? 'undefined' : _typeof(config)) !== 'object') throw Error('config should be an object!');
}