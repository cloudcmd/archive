'use strict';

module.exports = require('../server/cloudfunc');

