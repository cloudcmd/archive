define(function() {
	return ( /^\s+/ );
});
