webpackJsonp([13],{

/***/ 46:
/*!*****************************************!*\
  !*** ./client/modules/edit-file-vim.js ***!
  \*****************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\n/* global CloudCmd */\n\nconst exec = __webpack_require__(/*! execon */ 0);\nconst Key = CloudCmd.Key;\n\nconst Events = __webpack_require__(/*! ../dom/events */ 10);\n\nCloudCmd.EditFileVim = function EditFileVimProto(callback) {\n    const EditFileVim = this;\n    \n    const ConfigView  = {\n        bindKeys: false,\n        beforeClose: () => {\n            Events.rmKey(listener);\n        }\n    };\n    \n    function init(callback) {\n        exec.series([\n            CloudCmd.EditFile,\n            callback || EditFileVim.show,\n        ]);\n    }\n    \n    this.show = () => {\n        Events.addKey(listener);\n        \n        CloudCmd.EditFile\n            .show(ConfigView)\n            .getEditor()\n            .setOption('keyMap', 'vim');\n    };\n    \n    this.hide = () => {\n        CloudCmd.Edit.hide();\n    };\n    \n    function listener({keyCode, shiftKey}) {\n        if (shiftKey && keyCode === Key.ESC)\n            EditFileVim.hide();\n    }\n    \n    init(callback);\n};\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/edit-file-vim.js\n// module id = 46\n// module chunks = 13\n\n//# sourceURL=file://cloudcmd/client/modules/edit-file-vim.js");

/***/ })

},[46]);