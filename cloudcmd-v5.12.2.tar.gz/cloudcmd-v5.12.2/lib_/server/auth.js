'use strict';

(function () {
    'use strict';

    var DIR = './',
        httpAuth = require('http-auth'),
        criton = require('criton'),
        config = require(DIR + 'config');

    module.exports = function () {
        var auth = httpAuth.basic({
            realm: 'Cloud Commander'
        }, check);

        return middle(auth);
    };

    function middle(authentication) {
        return function (req, res, next) {
            var is = config('auth');

            if (!is) next();else authentication.check(req, res, function () /* success */{
                next();
            });
        };
    }

    function check(username, password, callback) {
        var BAD_CREDENTIALS = false,
            sameName,
            samePass,
            name = config('username'),
            pass = config('password'),
            algo = config('algo');

        if (!password) return callback(BAD_CREDENTIALS);

        sameName = username === name;
        samePass = pass === criton(password, algo);

        callback(sameName && samePass);
    }
})();