module.exports = require('../package');
