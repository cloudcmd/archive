# dropbox.js Test Automator

This is a Google Chrome extension that fully automates the dropbox.js test
suite. Read the
[dropbox.js development guide](https://github.com/dropbox/dropbox-js/tree/master/doc)
to learn how the extension fits into the testing process.

You're welcome to reuse the code to automate the testing of your own
application's integration with Dropbox.

