#!/bin/bash
#
# part of Cloud Commander
# *nix version
# secrets of github and dropbox
# must not be shared
# http://cloudcmd.io
#
# for using just add $-symbol on start of name
# like $github_secret

export github_secret=afe9bed1e810c5dc44c4c2a953fc6efb1e5b0545
