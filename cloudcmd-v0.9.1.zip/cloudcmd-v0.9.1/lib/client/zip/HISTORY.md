0.2.0 / 2014-04-18
------------------

- Added custom gzip headers support.
- Added strings support.
- Improved memory allocations for small chunks.
- ZStream properties rename/cleanup.
- More coverage tests.


0.1.1 / 2014-03-20
------------------

- Bugfixes for inflate/deflate.


0.1.0 / 2014-03-15
------------------

- First release.
