webpackJsonp([15],{

/***/ 36:
/* no static exports found */
/* all exports used */
/*!*********************************!*\
  !*** ./client/modules/cloud.js ***!
  \*********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/* global CloudCmd, filepicker */\n\n\n\nCloudCmd.Cloud = CloudProto;\n\nconst exec = __webpack_require__(/*! execon */ 0);\n\nconst load = __webpack_require__(/*! ../dom/load */ 2);\nconst Files = __webpack_require__(/*! ../dom/files */ 7);\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\nconst Util = __webpack_require__(/*! ../../common/util */ 6);\n\nfunction CloudProto(callback) {\n    exec.series([\n        loadFiles,\n        callback,\n    ]);\n    \n    return module.exports;\n}\n\nmodule.exports.uploadFile = (filename, data) => {\n    const {log} = CloudCmd;\n    const mimetype = '';\n    \n    filepicker.store(data, {\n        mimetype,\n        filename,\n    }, (fpFile) => {\n        log(fpFile);\n        filepicker.exportFile(fpFile, log, log);\n    });\n};\n\nmodule.exports.saveFile = (callback) => {\n    filepicker.pick((fpFile) => {\n        CloudCmd.log(fpFile);\n        const {url} = fpFile;\n        const responseType = 'arraybuffer';\n        const success = exec.with(callback, fpFile.filename);\n        \n        load.ajax({\n            url,\n            responseType,\n            success,\n        });\n    });\n};\n\nfunction loadFiles(callback) {\n    Util.time('filepicker load');\n    \n    load.js('//api.filepicker.io/v1/filepicker.js', () => {\n        Files.get('modules', (error, modules) => {\n            const {key} = modules.data.FilePicker;\n            \n            filepicker.setKey(key);\n            \n            Images.hide();\n            Util.timeEnd('filepicker loaded');\n            exec(callback);\n        });\n    });\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/cloud.js\n// module id = 36\n// module chunks = 15\n\n//# sourceURL=file://cloudcmd/client/modules/cloud.js");

/***/ })

},[36]);