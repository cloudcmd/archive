'use strict';

var deepmerge = require('deepmerge');
var originalModules = require('../json/modules');

module.exports = function (modules) {
    var result = deepmerge(originalModules, modules || {});

    return function (req, res, next) {
        if (req.url !== '/json/modules.json') return next();

        res.send(result);
    };
};