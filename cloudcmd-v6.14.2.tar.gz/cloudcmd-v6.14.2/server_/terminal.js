'use strict';

var tryCatch = require('try-catch');
var config = require('./config');

var noop = function noop() {};
noop.listen = noop;

module.exports = function (arg) {
    return getTerminal(config('terminal'), arg);
};

function getTerminal(term, arg) {
    if (!term) return noop;

    var result = void 0;

    var e = tryCatch(function () {
        result = require(config('terminalPath'));
    });

    if (!e && !arg) return result;

    if (!e) return result(arg);

    config('terminal', false);
    console.log('cloudcmd --terminal: ' + e.message);

    return noop;
}