'use strict';

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

var rendy = require('rendy');
var Entity = require('./common/entity');
var store = require('./common/store');

/* КОНСТАНТЫ (общие для клиента и сервера)*/

/* название программы */
var NAME = 'Cloud Commander';
var FS = '/fs';

var Path = store();

Path('/');

module.exports.FS = FS;
module.exports.apiURL = '/api/v1';
module.exports.MAX_FILE_SIZE = 500 * 1024;
module.exports.Entity = Entity;

module.exports.formatMsg = function (msg, name, status) {
    status = status || 'ok';

    if (name) name = '("' + name + '")';else name = '';

    return msg + ': ' + status + name;
};

/**
 * Функция возвращает заголовок веб страницы
 * @path
 */
module.exports.getTitle = function (path) {
    return NAME + ' - ' + (path || Path());
};

/** Функция получает адреса каждого каталога в пути
 * возвращаеться массив каталогов
 * @param url -  адрес каталога
 */
function getPathLink(url, prefix, template) {
    if (!url) throw Error('url could not be empty!');

    if (!template) throw Error('template could not be empty!');

    var names = url.split('/').slice(1, -1);

    var allNames = ['/'].concat(_toConsumableArray(names));
    var length = allNames.length - 1;

    var path = '/';

    var pathHTML = allNames.map(function (name, index) {
        var isLast = index === length;

        if (index) path += name + '/';

        if (index && isLast) return name + '/';

        var slash = index ? '/' : '';

        return rendy(template, {
            path: path,
            name: name,
            slash: slash,
            prefix: prefix
        });
    }).join('');

    return pathHTML;
}

/**
 * Функция строит таблицу файлв из JSON-информации о файлах
 * @param params - информация о файлах
 *
 */
module.exports.buildFromJSON = function (params) {
    var prefix = params.prefix;
    var template = params.template;
    var templateFile = template.file;
    var templateLink = template.link;
    var json = params.data;

    var path = json.path,
        files = json.files;


    var sort = params.sort || 'name';
    var order = params.order || 'asc';

    /*
     * Строим путь каталога в котором мы находимся
     * со всеми подкаталогами
     */
    var htmlPath = getPathLink(path, prefix, template.pathLink);

    var fileTable = rendy(template.path, {
        link: prefix + FS + path,
        fullPath: path,
        path: htmlPath
    });

    var name = 'name';
    var size = 'size';
    var date = 'date';
    var owner = 'owner';
    var mode = 'mode';
    var arrow = order === 'asc' ? '↑' : '↓';

    if (sort === 'name' && order !== 'asc') name += arrow;else if (sort === 'size') size += arrow;else if (sort === 'date') date += arrow;

    var header = rendy(templateFile, {
        tag: 'div',
        attribute: 'data-name="js-fm-header" ',
        className: 'fm-header',
        type: '',
        name: name,
        size: size,
        date: date,
        owner: owner,
        mode: mode
    });

    /* сохраняем путь */
    Path(path);

    fileTable += header + '<ul data-name="js-files" class="files">';
    /* Если мы не в корне */
    if (path !== '/') {
        /* убираем последний слеш и каталог в котором мы сейчас находимся*/
        var lastSlash = path.substr(path, path.lastIndexOf('/'));
        var dotDot = lastSlash.substr(lastSlash, lastSlash.lastIndexOf('/'));

        var link = prefix + FS + (dotDot || '/');

        var linkResult = rendy(template.link, {
            link: link,
            title: '..',
            name: '..'
        });

        var dataName = 'data-name="js-file-.." ';
        var attribute = 'draggable="true" ' + dataName;

        /* Сохраняем путь к каталогу верхнего уровня*/
        fileTable += rendy(template.file, {
            tag: 'li',
            attribute: attribute,
            className: '',
            type: 'directory',
            name: linkResult,
            size: '&lt;dir&gt;',
            date: '--.--.----',
            owner: '.',
            mode: '--- --- ---'
        });
    }

    fileTable += files.map(function (file) {
        var link = prefix + FS + path + file.name;

        var type = getType(file.size);
        var size = getSize(file.size);

        var date = file.date || '--.--.----';
        var owner = file.owner || 'root';
        var mode = file.mode;

        var linkResult = rendy(templateLink, {
            link: link,
            title: file.name,
            name: Entity.encode(file.name),
            attribute: getAttribute(file.size)
        });

        var dataName = 'data-name="js-file-' + file.name + '" ';
        var attribute = 'draggable="true" ' + dataName;

        return rendy(templateFile, {
            tag: 'li',
            attribute: attribute,
            className: '',
            type: type,
            name: linkResult,
            size: size,
            date: date,
            owner: owner,
            mode: mode
        });
    }).join('');

    fileTable += '</ul>';

    return fileTable;
};

function getType(size) {
    if (size === 'dir') return 'directory';

    return 'text-file';
}

function getAttribute(size) {
    if (size === 'dir') return '';

    return 'target="_blank" ';
}

function getSize(size) {
    if (size === 'dir') return '&lt;dir&gt;';

    return size;
}