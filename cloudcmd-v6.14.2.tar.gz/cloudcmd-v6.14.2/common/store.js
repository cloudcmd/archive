'use strict';

module.exports = require('../server/common/store');

