webpackJsonp([10],{

/***/ 49:
/*!********************************!*\
  !*** ./client/modules/help.js ***!
  \********************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\n/* global CloudCmd */\n\nCloudCmd.Help = HelpProto;\n\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\n\nfunction HelpProto() {\n    Images.show.load('top');\n    show();\n    \n    return exports;\n}\n\nmodule.exports.show = show;\nmodule.exports.hide = hide;\n\nfunction show() {\n    const positionLoad = 'top';\n    const relative = true;\n    \n    CloudCmd\n        .Markdown\n        .show('/HELP.md', {\n            positionLoad,\n            relative,\n        });\n}\n\nfunction hide() {\n    CloudCmd.View.hide();\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/help.js\n// module id = 49\n// module chunks = 10\n\n//# sourceURL=file://cloudcmd/client/modules/help.js");

/***/ })

},[49]);