'use strict';

module.exports = function () {
    var data = {};

    return function (value) {
        if (typeof value !== 'undefined') data.value = value;

        return data.value;
    };
};