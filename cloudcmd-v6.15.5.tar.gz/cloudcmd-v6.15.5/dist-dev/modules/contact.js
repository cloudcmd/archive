webpackJsonp([14],{

/***/ 57:
/*!***********************************!*\
  !*** ./client/modules/contact.js ***!
  \***********************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/* global CloudCmd */\n/* global DOM */\n/* global olark */\n\n\n\nCloudCmd.Contact = ContactProto;\n\nconst exec = __webpack_require__(/*! execon */ 0);\nconst Images = __webpack_require__(/*! ../dom/images */ 1);\n\nfunction ContactProto(callback) {\n    init(callback);\n    \n    return exports;\n}\n\nconst Events = DOM.Events;\nconst Key = CloudCmd.Key;\n\nmodule.exports.show = show;\nmodule.exports.hide = hide;\n\nlet Inited = false;\n\nfunction init(callback) {\n    if (Inited)\n        return;\n    \n    load(() => {\n        Inited = true;\n        \n        olark.identify('6216-545-10-4223');\n        olark('api.box.onExpand', show);\n        olark('api.box.onShow', show);\n        olark('api.box.onShrink', hide);\n        \n        exec(callback);\n    });\n    \n    Events.addKey(onKey);\n}\n\nfunction load(callback) {\n    const {PREFIX} = CloudCmd;\n    const path = `${PREFIX}/modules/olark/olark.min.js`;\n    \n    Images.show.load('top');\n    \n    DOM.load.js(path, callback);\n}\n\nfunction show() {\n    Key.unsetBind();\n    Images.hide();\n    \n    if (Inited)\n        return olark('api.box.expand');\n    \n    init(show);\n}\n\nfunction hide() {\n    Key.setBind();\n    olark('api.box.hide');\n}\n\nfunction onKey({keyCode}) {\n    if (keyCode === Key.ESC)\n        hide();\n}\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./client/modules/contact.js\n// module id = 57\n// module chunks = 14\n\n//# sourceURL=file://cloudcmd/client/modules/contact.js");

/***/ })

},[57]);