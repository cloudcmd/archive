'use strict';

var env = process.env;
var up = function up(a) {
    return a.toUpperCase();
};

module.exports = parse;
module.exports.bool = function (name) {
    var value = parse(name);

    if (value === 'false') return false;

    return value;
};

function parse(name) {
    var small = 'cloudcmd_' + name;
    var big = up(small);

    return env[small] || env[big];
}