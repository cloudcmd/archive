<!--
Thank you for reporting an issue. Please fill in the template below. If unsure
about something, just do as best as you're able.
-->

* **Version** (`cloudcmd -v`): 
* **Node Version** `node -v`: 
* **OS** (`uname -a` on Linux): 
* **Browser name/version**: 

