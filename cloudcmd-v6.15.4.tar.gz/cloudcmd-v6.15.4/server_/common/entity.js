'use strict';

var Entities = {
    '&nbsp;': ' ',
    '&lt;': '<',
    '&gt;': '>'
};

var keys = Object.keys(Entities);

module.exports.encode = function (str) {
    keys.forEach(function (code) {
        var char = Entities[code];
        var reg = RegExp(char, 'g');

        str = str.replace(reg, code);
    });

    return str;
};

module.exports.decode = function (str) {
    keys.forEach(function (code) {
        var char = Entities[code];
        var reg = RegExp(code, 'g');

        str = str.replace(reg, char);
    });

    return str;
};