'use strict';

var DIR = __dirname + '/';
var DIR_ROOT = DIR + '../';

var cloudfunc = require(DIR + 'cloudfunc');
var auth = require(DIR + 'auth');
var config = require(DIR + 'config');
var modulas = require(DIR + 'modulas');
var rest = require(DIR + 'rest');
var route = require(DIR + 'route');
var validate = require(DIR + 'validate');
var prefixer = require(DIR + 'prefixer');
var pluginer = require(DIR + 'plugins');
var terminal = require(DIR + 'terminal');

var currify = require('currify');
var apart = require('apart');
var join = require('join-io');
var ponse = require('ponse');
var restafary = require('restafary/legacy');
var konsole = require('console-io/legacy');
var edward = require('edward/legacy');
var dword = require('dword/legacy');
var deepword = require('deepword/legacy');
var nomine = require('nomine/legacy');
var spero = require('spero/legacy');
var remedy = require('remedy/legacy');
var ishtar = require('ishtar/legacy');
var salam = require('salam/legacy');
var omnes = require('omnes/legacy');
var criton = require('criton');

var setUrl = currify(_setUrl);

var root = function root() {
    return config('root');
};

var notEmpty = function notEmpty(a) {
    return a;
};
var clean = function clean(a) {
    return a.filter(notEmpty);
};

var isDev = process.env.NODE_ENV === 'development';

function getPrefix(prefix) {
    if (typeof prefix === 'function') return prefix() || '';

    return prefix || '';
}

module.exports = function (params) {
    var p = params || {};
    var options = p.config || {};
    var plugins = p.plugins;
    var modules = p.modules;

    var keys = Object.keys(options);

    var prefix = void 0;

    checkPlugins(plugins);

    keys.forEach(function (name) {
        var value = options[name];

        switch (name) {
            case 'root':
                validate.root(value);
                break;
            case 'editor':
                validate.editor(value);
                break;
            case 'packer':
                validate.packer(value);
                break;
            case 'password':
                /* could be useful when used as middleware */
                value = criton(value, config('algo'));
                break;
            case 'prefix':
                prefix = prefixer(value);
                break;
        }

        config(name, value);
    });

    config('console', defaultValue('console', options));
    config('configDialog', defaultValue('configDialog', options));

    if (p.socket) listen(prefix, p.socket);

    return cloudcmd(prefix, plugins, modules);
};

function defaultValue(name, options) {
    var value = options[name];
    var previous = config(name);

    if (typeof value === 'undefined') return previous;

    return value;
}

function authCheck(socket, success) {
    if (!config('auth')) return success();

    socket.on('auth', function (name, pass) {
        var isName = name === config('username');
        var isPass = pass === config('password');

        if (!isName || !isPass) return socket.emit('reject');

        success();
        socket.emit('accept');
    });
}

function listen(prefix, socket) {
    var size = cloudfunc.MAX_SIZE;

    prefix = getPrefix(prefix);

    config.listen(socket, authCheck);

    edward.listen(socket, {
        size: size,
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/edward'
    });

    dword.listen(socket, {
        size: size,
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/dword'
    });

    deepword.listen(socket, {
        size: size,
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/deepword'
    });

    spero.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/spero'
    });

    remedy.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/remedy'
    });

    ishtar.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/ishtar'
    });

    salam.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/salam'
    });

    omnes.listen(socket, {
        root: root,
        authCheck: authCheck,
        prefix: prefix + '/omnes'
    });

    config('console') && konsole.listen(socket, {
        authCheck: authCheck,
        prefix: prefix + '/console'
    });

    config('terminal') && terminal().listen(socket, {
        authCheck: authCheck,
        prefix: prefix + '/gritty'
    });
}

function cloudcmd(prefix, plugins, modules) {
    var isOption = function isOption(name) {
        return config(name);
    };

    var minify = apart(isOption, 'minify');
    var online = apart(isOption, 'online');
    var cache = apart(isOption, 'cache');
    var diff = apart(isOption, 'diff');
    var zip = apart(isOption, 'zip');

    var ponseStatic = ponse.static(DIR_ROOT, { cache: cache });

    var funcs = clean([config('console') && konsole({
        prefix: prefix + '/console',
        online: online
    }), config('terminal') && terminal({
        prefix: prefix + '/gritty'
    }), edward({
        prefix: prefix + '/edward',
        online: online,
        diff: diff,
        zip: zip
    }), dword({
        prefix: prefix + '/dword',
        online: online,
        diff: diff,
        zip: zip
    }), deepword({
        prefix: prefix + '/deepword',
        online: online,
        diff: diff,
        zip: zip
    }), spero({
        prefix: prefix + '/spero',
        online: online
    }), remedy({
        prefix: prefix + '/remedy',
        online: online
    }), ishtar({
        prefix: prefix + '/ishtar',
        online: online
    }), salam({
        prefix: prefix + '/salam'
    }), omnes({
        prefix: prefix + '/omnes'
    }), nomine({
        prefix: prefix + '/rename'
    }), setUrl(prefix), logout, auth(), config.middle, modules && modulas(modules), restafary({
        prefix: cloudfunc.apiURL + '/fs',
        root: root
    }), rest, route, join({
        dir: DIR_ROOT,
        minify: minify
    }), pluginer(plugins), ponseStatic]);

    return funcs;
}

function logout(req, res, next) {
    if (req.url !== '/logout') return next();

    res.sendStatus(401);
}

function _setUrl(pref, req, res, next) {
    var prefix = getPrefix(pref);
    var is = !req.url.indexOf(prefix);

    if (!is) return next();

    req.url = req.url.replace(prefix, '') || '/';

    if (/^\/cloudcmd\.js(\.map)?$/.test(req.url)) req.url = '/dist' + req.url;

    if (isDev) req.url = req.url.replace(/^\/dist\//, '/dist-dev/');

    next();
}

function checkPlugins(plugins) {
    if (typeof plugins === 'undefined') return;

    if (!Array.isArray(plugins)) throw Error('plugins should be an array!');
}