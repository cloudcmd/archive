0.2.5 / 2014-07-19
------------------

- Workaround for Chrome 38.0.2096.0 script parser bug, #30


0.2.4 / 2014-07-07
------------------

- Fixed bug in inflate wrapper, #29


0.2.3 / 2014-06-09
------------------

- Maintenance release, dependencies update.


0.2.2 / 2014-06-04
------------------

- Fixed iOS 5.1 Safary issue with `apply(typed_array)`, #26.


0.2.1 / 2014-05-01
------------------

- Fixed collision on switch dynamic/fixed tables.


0.2.0 / 2014-04-18
------------------

- Added custom gzip headers support.
- Added strings support.
- Improved memory allocations for small chunks.
- ZStream properties rename/cleanup.
- More coverage tests.


0.1.1 / 2014-03-20
------------------

- Bugfixes for inflate/deflate.


0.1.0 / 2014-03-15
------------------

- First release.
